jQuery(document).ready(function(){ window.Lightbox = new jQuery().visualLightbox({autoPlay:false,borderSize:57,classNames:'vlightbox1', closeLocation:'top',descSliding:true,enableRightClick:false,enableSlideshow:true,overlayOpacity:0,prefix:'vlb1',resizeSpeed:9,slideTime:9,startZoom:true}) });

jQuery(document).ready(function(){ window.Lightbox = new jQuery().visualLightbox({autoPlay:false,borderSize:57,classNames:'vlightbox2', closeLocation:'top',descSliding:true,enableRightClick:false,enableSlideshow:true,overlayOpacity:0,prefix:'vlb1',resizeSpeed:9,slideTime:9,startZoom:true}) });

jQuery(document).ready(function(){ window.Lightbox = new jQuery().visualLightbox({autoPlay:false,borderSize:57,classNames:'vlightbox3', closeLocation:'top',descSliding:true,enableRightClick:false,enableSlideshow:true,overlayOpacity:0,prefix:'vlb1',resizeSpeed:9,slideTime:9,startZoom:true}) });


jQuery(document).ready(function(){ window.Lightbox = new jQuery().visualLightbox({autoPlay:false,borderSize:57,classNames:'vlightbox4', closeLocation:'top',descSliding:true,enableRightClick:false,enableSlideshow:true,overlayOpacity:0,prefix:'vlb1',resizeSpeed:9,slideTime:9,startZoom:true}) });


jQuery(document).ready(function(){ window.Lightbox = new jQuery().visualLightbox({autoPlay:false,borderSize:57,classNames:'vlightbox5', closeLocation:'top',descSliding:true,enableRightClick:false,enableSlideshow:true,overlayOpacity:0,prefix:'vlb1',resizeSpeed:9,slideTime:9,startZoom:true}) });

